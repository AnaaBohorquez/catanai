# El módulo `variables.py`

> Guía de estudio del segundo archivo del dominio. Explica cómo una pareja de poblados se convierte en los números que usa el modelo. Complementa a `dominio-tablero.md`: el tablero es la materia prima y este módulo es la receta.

**Ubicación:** `backend/app/domain/variables.py`

---

## 1. Qué hace el módulo

`variables.py` toma una **pareja de vértices** (los dos poblados iniciales) y calcula **40 números** que describen qué tan buena es. Cada pareja se vuelve una fila de un dataset.

En ciencia de datos esto se llama **ingeniería de variables** (*feature engineering*). Es la misma idea que los factores de tarificación en seguros: una póliza se describe con edad, zona e historial para estimar su prima, y aquí una pareja se describe con su producción, sus combinaciones de recursos y sus puertos para estimar cuántos puntos va a sacar.

**Lo que no hace:** no simula nada. Solo aplica fórmulas. Las partidas simuladas están en `simulador.py`.

### Dónde encaja en el proyecto

![Del tablero al modelo](img/variables-flujo-datos.svg)

| Archivo | Qué hace | Papel en el modelo |
|---|---|---|
| `tablero.py` | Representa el tablero y sus reglas | La materia prima |
| `variables.py` | Convierte cada pareja en 40 números con fórmulas | **X**: las variables |
| `simulador.py` | Juega partidas simuladas con cada pareja y cuenta sus puntos | **y**: la variable objetivo |
| `generar_dataset.py` | Junta X y y en `parejas.csv` | El dataset |
| `02_modelo.ipynb` | Aprende la relación entre X y y | El modelo entrenado |

Hace falta simular porque no existe una base pública de partidas reales de Catan. El proyecto genera sus propios ejemplos con respuesta conocida, un enfoque que aprobó el profesor.

### Las dos reglas del módulo

1. **Se describen parejas, no vértices sueltos.** En Catan se colocan dos poblados, así que la decisión real es la pareja. Un vértice toca máximo tres hexágonos y solo tiene madera y ladrillo juntos en el 9% de los casos; una pareja toca hasta seis y lo logra en el 48%.
2. **Una variable solo sirve si cambia entre las parejas del mismo tablero.** La app ordena las parejas de un tablero. Algo que vale igual para todas (el total de pips del tablero, por ejemplo) no puede explicar por qué una es mejor que otra. `verificar_variabilidad()` lo revisa automáticamente.

---

## 2. La idea base: los pips son cartas

Al tirar dos dados hay 36 combinaciones posibles. Los **pips** de un número son cuántas de esas 36 combinaciones lo producen.

![Las 36 combinaciones de dos dados](img/variables-dados-36.svg)

![Pips por número](img/variables-pips-por-suma.svg)

La consecuencia que usa todo el módulo:

> **Los pips de un recurso son las cartas de ese recurso que esperas recibir por cada 36 tiradas.**

Si una pareja tiene 7 pips de madera, de cada 36 tiradas unas 7 le dan madera. A partir de aquí, todas las variables son cuentas de cartas.

---

## 3. El ejemplo de todo el documento: la pareja B

Tablero generado con `generar_tablero(semilla=42)`, con 4 jugadores.

![Pareja B en el tablero de semilla 42](img/variables-pareja-b.svg)

| Poblado | Terreno | Número | Pips | Recurso |
|---|---|---|---|---|
| 1 | Pastos | 11 | 2 | oveja |
| 1 | Colinas | 9 | 4 | ladrillo |
| 1 | Colinas | 8 | 5 | ladrillo |
| 2 | Bosque | 5 | 4 | madera |
| 2 | Bosque | 4 | 3 | madera |
| 2 | Campos | 10 | 3 | trigo |

**Pips por recurso:** madera 7, ladrillo 9, trigo 3, oveja 2, mineral 0. Total: 21. No toca desierto ni puertos.

**Pips de todo el tablero:** madera 17, ladrillo 13, trigo 11, oveja 11, mineral 6.

Como contraste se usa la **pareja A**, que comparte el poblado 1 pero pone el segundo entre un campo con 6, un pasto con 5 y una montaña con 4. Tiene más pips (23: madera 0, ladrillo 9, trigo 5, oveja 6, mineral 3), pero ninguna madera.

---

## 4. Las 40 variables

![Familias de variables](img/variables-familias.svg)

La marca ✓ indica que la variable entra al modelo final de 12.

### Fase 1: directas (lo que se lee del tablero)

| Variable | Qué mide | Pareja B | Modelo |
|---|---|---|---|
| `pips_totales` | Suma de pips de los dos poblados | 21 | |
| `pips_madera` … `pips_mineral` | Pips de cada recurso (5 variables) | 7, 9, 3, 2, 0 | |
| `num_hexagonos` | Hexágonos que tocan, contando repetidos | 6 | ✓ |
| `hexagonos_distintos` | Hexágonos distintos que tocan | 6 | |
| `num_recursos_distintos` | Cuántos de los 5 recursos produce | 4 | |
| `toca_desierto` | 1 si algún poblado toca el desierto | 0 | |
| `num_puertos` | Puertos a los que tiene acceso | 0 | |
| `puerto_generico` | 1 si tiene un puerto 3:1 | 0 | ✓ |
| `puerto_especifico` | 1 si tiene un puerto 2:1 | 0 | |
| `jugadores` | 3 o 4 | 4 | ✓ |

### Fase 2: combinaciones y forma de la producción

| Variable | Qué mide | Pareja B | Modelo |
|---|---|---|---|
| `par_camino` | min(madera, ladrillo) | 7 | ✓ |
| `cuarteto_poblado` | min(madera, ladrillo, trigo, oveja) | 2 | ✓ |
| `par_ciudad` | min(trigo ÷ 2, mineral ÷ 3) | 0 | ✓ |
| `trio_desarrollo` | min(trigo, oveja, mineral) | 0 | ✓ |
| `control_madera` … `control_mineral` | Tus pips ÷ pips del tablero (5 variables) | 0.41, 0.69, 0.27, 0.18, 0 | |
| `control_suministro` | Suma de los 5 controles | 1.56 | |
| `control_maximo` | El mayor de los 5 controles | 0.69 | |
| `desequilibrio` | Pips del recurso más fuerte ÷ pips totales | 9 ÷ 21 = 0.43 | ✓ |
| `puerto_alineado` | 1 si tiene puerto 2:1 del recurso que más produce | 0 | ✓ |

### Fase 3: dominio (comercio, tiempo y espacio)

| Variable | Qué mide | Pareja B | Modelo |
|---|---|---|---|
| `produccion_efectiva` | Cartas útiles, contando el sobrante a su valor de cambio | 15.3 | ✓ |
| `turnos_a_camino` | Rondas estimadas hasta juntar un camino | 1.3 | |
| `turnos_a_poblado` | Rondas hasta juntar un poblado | 4.5 | |
| `turnos_a_ciudad` | Rondas hasta juntar una ciudad | 12 | |
| `turnos_a_carta_desarrollo` | Rondas hasta juntar una carta | 4.5 | |
| `vertices_expansion_2` | Esquinas libres a 2 aristas de tus poblados | 12 | ✓ |
| `vertices_expansion_3` | Esquinas libres a 3 aristas | 14 | |
| `pips_vecinos_max` | Pips de la mejor esquina cercana libre | 9 | |
| `pips_vecinos_media` | Pips promedio de las esquinas cercanas | 6.2 | |
| `aristas_cercanas` | Lados disponibles para caminos a 3 pasos | 38 | |

### Solo existen a nivel de pareja

| Variable | Qué mide | Pareja B | Modelo |
|---|---|---|---|
| `solapamiento` | Hexágonos que comparten los dos poblados | 0 | ✓ |
| `distancia` | Aristas entre los dos poblados | 7 | |
| `complementariedad` | Recursos que aporta la pareja y que ninguno tenía solo | 2 | |

---

## 5. Fase 2: por qué el mínimo

Cada construcción es una receta. Un camino lleva 1 madera y 1 ladrillo, igual que una torta lleva 1 pan y 1 jamón: con 7 panes y 9 jamones haces 7 tortas y te sobran 2 jamones.

![Por qué se usa el mínimo](img/variables-minimo-caminos.svg)

Cada línea une una madera con un ladrillo y forma un camino. El número de caminos siempre es el número de cartas del recurso que menos tienes: eso es el mínimo.

La pareja A tiene más pips (23 contra 21), pero sin madera no forma ni un camino. Si el modelo solo viera `pips_totales`, preferiría la A; con `par_camino` detecta el problema. El modelo entrenado pone a la B en el lugar 8 de 192 parejas candidatas y a la A en el 24.

### Por qué a veces se divide

Cuando la receta pide más de una unidad de un ingrediente, se divide entre esa cantidad antes de sacar el mínimo. Así, cada número se vuelve "construcciones que me alcanzan con este ingrediente" y se pueden comparar.

![Por qué se divide entre 2 y entre 3](img/variables-par-ciudad.svg)

Sin dividir, `min(6, 6) = 6` diría que el trigo y el mineral alcanzan igual, y es falso: una ciudad pide 3 minerales pero solo 2 trigos. En el camino, el poblado y la carta la división no se nota porque piden 1 de cada ingrediente.

| Construcción | Receta | Variable |
|---|---|---|
| Camino | 1 madera + 1 ladrillo | `par_camino` = min(madera, ladrillo) |
| Poblado | 1 madera + 1 ladrillo + 1 trigo + 1 oveja | `cuarteto_poblado` = min de los cuatro |
| Ciudad | 2 trigos + 3 minerales | `par_ciudad` = min(trigo ÷ 2, mineral ÷ 3) |
| Carta de desarrollo | 1 trigo + 1 oveja + 1 mineral | `trio_desarrollo` = min de los tres |

Ninguna pareja es buena en todo. La B arranca fuerte en caminos (7) pero tiene 0 en ciudades y cartas porque no produce mineral. Por eso el modelo necesita las cuatro: cada una mide una estrategia distinta.

### Control del suministro y forma de la producción

- **Control:** qué fracción de un recurso del tablero es tuya. La B controla el 69% del ladrillo (9 de 13) y el 41% de la madera (7 de 17). Controlar lo escaso vale más. Puede pasar de 1 si los dos poblados tocan el mismo hexágono, porque se cobra doble.
- **`desequilibrio`:** qué tan concentrada está la producción en un solo recurso.
- **`puerto_alineado`:** vale 1 si tienes un puerto 2:1 justo del recurso que más produces, que es cuando un puerto de verdad rinde.

---

## 6. Fase 3: producción efectiva

Idea: las cartas que te sobran no se pierden, pero valen menos, porque hay que cambiarlas en el banco a 4 por 1.

![El sobrante se cambia en el banco](img/variables-sobrante-banco.svg)

La única duda es **cuántas cartas de cada recurso "usas"**. El código usa una regla simple: supone que necesitas los 5 recursos por igual. La pareja B recibe 21 cartas, así que el reparto parejo es 21 ÷ 5 = 4.2 de cada uno.

![Producción efectiva de la pareja B](img/variables-produccion-efectiva.svg)

- **Madera:** recibes 7, usas 4.2 y te sobran 2.8. Las 2.8 valen 2.8 ÷ 4 = 0.7. Total: 4.9.
- **Ladrillo:** 4.2 + (4.8 ÷ 4) = 5.4.
- **Trigo y oveja:** no llegan a 4.2, así que no sobra nada y cuentan completos: 3 y 2.
- **Total:** 15.3 cartas útiles de 21.

Con puertos cambia la división: un puerto 3:1 divide todos los sobrantes entre 3, y un puerto 2:1 de ladrillo dividiría el sobrante de ladrillo entre 2 (4.2 + 4.8 ÷ 2 = 6.6).

En el código:

```python
equilibrio = pips_totales / 5.0
for recurso in RECURSOS:
    tasa = _tasa_de_cambio(recurso, puertos)          # 4, 3 o 2
    efectiva += min(pr[recurso], equilibrio) + max(0.0, pr[recurso] - equilibrio) / tasa
```

**Simplificación:** el reparto parejo no es real. Al inicio de la partida pesan la madera y el ladrillo (caminos y poblados), y al final el trigo y el mineral (ciudades).

---

## 7. Fase 3: turnos para construir

Una **ronda** es una vuelta a la mesa: con 4 jugadores se tiran los dados 4 veces. En cada tirada la probabilidad de recibir madera es pips ÷ 36, así que:

> cartas por ronda = jugadores × pips ÷ 36

La madera de la pareja B da 4 × 7 ÷ 36 = 0.78 cartas por ronda: **1 madera cada 1.3 rondas**.

| Recurso | Pips | Cartas por ronda | Una carta cada |
|---|---|---|---|
| Madera | 7 | 0.78 | 1.3 rondas |
| Ladrillo | 9 | 1.00 | 1 ronda |
| Trigo | 3 | 0.33 | 3 rondas |
| Oveja | 2 | 0.22 | 4.5 rondas |
| Mineral | 0 | 0 | nunca |

Para cada construcción se calcula cuánto tarda cada ingrediente y **manda el más lento**. Es el mismo principio del mínimo, pero al revés: aquí se mide tiempo en vez de cantidad.

![Rondas hasta juntar un poblado](img/variables-turnos-poblado.svg)

- **Poblado:** la madera llega en 1.3, el ladrillo en 1 y el trigo en 3, pero la oveja tarda 4.5. `turnos_a_poblado = 4.5`.
- **Camino:** manda la madera. `turnos_a_camino = 1.3`.
- **Ciudad:** no hay mineral. El código supone que lo consigues cambiando tu recurso más abundante (ladrillo, 1 por ronda) a 4 por 1. Tres minerales cuestan 12 ladrillos: `turnos_a_ciudad = 12`.
- Si no hay forma de conseguir un recurso, se topa en 60 rondas (`TOPE_TURNOS`), que significa "no llegas".

Son **cuentas promedio, no simulaciones**. En una partida real los dados son irregulares; para eso está el simulador.

**Simplificaciones:** cada construcción se calcula por separado, como si todo el sobrante estuviera libre para cambiar, y no se consideran el ladrón ni el descarte con el 7. Ninguna de las 4 variables de turnos entró al modelo.

---

## 8. Fase 3: espacio de expansión y variables de pareja

Por la regla de distancia, las esquinas pegadas a tus poblados nunca son legales. Por eso se cuentan las esquinas libres a **2 y 3 aristas** de distancia, sus pips y los lados disponibles para caminos. Las distancias se calculan una sola vez con una búsqueda en anchura (`_distancias_desde`), porque la geometría del tablero es la misma en todos los tableros.

Solo `vertices_expansion_2` entró al modelo, con un coeficiente ligeramente negativo. En un tablero vacío cualquier esquina tiene espacio, y la expansión importa cuando hay rivales, pero el simulador juega en solitario.

Las variables de pareja miden cómo se combinan los dos poblados:

- **`solapamiento`:** si comparten hexágonos, la producción se concentra en pocos números. Suele ser malo.
- **`distancia`:** qué tan separados están, que influye en si sus caminos llegan a unirse.
- **`complementariedad`:** cuántos recursos aporta la pareja que ninguno de los dos tenía solo.

---

## 9. Funciones principales

| Función | Qué hace |
|---|---|
| `variables_de_pareja(v1, v2, tablero, jugadores)` | Calcula las 40 variables de una pareja. Es el corazón del módulo |
| `variables_de_parejas(tablero, parejas, jugadores)` | Aplica lo anterior a una lista y agrega `pareja_id` |
| `pips_por_recurso_del_tablero(tablero)` | Pips de cada recurso en todo el tablero; se calcula una vez por tablero |
| `identificador(v1, v2)` | Texto único de una pareja, sin importar el orden |
| `verificar_variables(...)` | Revisa que no haya NaN ni infinitos, que los pips cuadren con `tablero.py`, que la distancia sea al menos 2 y que el control esté entre 0 y 2 |
| `verificar_variabilidad(tableros=20)` | Revisa que ninguna variable sea constante en 20 tableros |

Para ejecutar el módulo desde `backend/` (necesita también `simulador.py`):

```
uv run python -m app.domain.variables
```

Imprime las 40 variables de 192 parejas candidatas del tablero de semilla 42, corre las dos verificaciones y muestra las 6 parejas con más pips.

---

## 10. Qué tan bien explican las variables

Experimento hecho con un dataset chico de 48 tableros y validación cruzada agrupada por tablero, igual que en el notebook:

![Qué tanto explica cada modelo](img/variables-r2-modelos.svg)

- **Techo por azar (0.98):** se simularon las mismas 1,151 parejas dos veces con semillas distintas y se correlacionaron en 0.98. El azar de los dados casi no pesa; un modelo perfecto llegaría cerca de 0.98.
- **Más variables en el modelo lineal ayuda poco** (0.60 → 0.64), igual que en `AGENTS.md` (0.633 → 0.656).
- **Con las mismas 40 variables, un modelo no lineal llega a 0.86.** La información ya está en las variables; lo que le falta a la regresión lineal es captar **combinaciones**, porque solo suma efectos por separado.

**Decisión tomada:** seguir con regresión lineal (por interpretabilidad) y agregar **variables de interacción con sentido de juego**, como ya hace `par_ciudad`. Las ideas se proponen desde la experiencia de juego y se prueban una por una.

Los números salen de 48 tableros, no de 200: son estimaciones. Y el techo mide qué tan bien se predice **al simulador**, no una partida real.

---

## 11. Ideas por explorar

Conceptos de Catan que las 40 variables no capturan, para revisar y ampliar:

- **Reparto por etapa del juego** en lugar del reparto parejo de `produccion_efectiva`.
- **Diversidad de números:** 21 pips repartidos en cinco números son más estables que concentrados en uno.
- **Exposición al ladrón:** los hexágonos de 6 y 8 son el blanco favorito.
- **Recursos de la primera ronda:** lo que recibes al colocar el segundo poblado.
- **Posición en el orden de colocación.**
- **Interacciones:** trigo × mineral, producción × puertos.

Cómo se evalúa cada idea:

1. ¿Se puede calcular solo con el tablero y la pareja?
2. ¿Cambia entre parejas del mismo tablero? (`verificar_variabilidad`)
3. ¿Sube el R² con validación agrupada por tablero?
4. ¿La puede medir el simulador? Si depende de rivales, el simulador actual no puede enseñarle su valor al modelo.

---

## 12. Preguntas probables en el Q&A

- **¿Por qué no eliges los vértices con más pips?** Porque la producción que no se combina en construcciones vale poco. La pareja A tiene más pips que la B pero no puede construir caminos.
- **¿Por qué parejas y no vértices?** Porque se colocan dos poblados y la complementariedad solo existe en pareja.
- **¿Por qué el mínimo?** Porque una construcción necesita todos sus ingredientes; el escaso limita.
- **¿Por qué solo 12 de 40 variables?** Pasar a 40 sube el R² muy poco en el modelo lineal, y con 12 los coeficientes se pueden explicar.
- **¿Por qué regresión lineal si un boosting llega a 0.86?** Porque los coeficientes son la explicación que ve el usuario. La brecha se ataca con variables de interacción.

---

## 13. Pendientes detectados al revisar el módulo

- **R² inconsistente:** el modelo guardado dice 0.642 y `AGENTS.md` dice 0.633.
- **`spec-variables.md` desactualizado:** menciona `src/variables.py` y `espacio_ruta_larga`, que se eliminó y se reemplazó por `aristas_cercanas`.
- **`jugadores` rompe la regla 2:** vale igual para todas las parejas de una partida. Tiene un coeficiente grande (+0.50) pero no cambia el orden de las recomendaciones, solo el nivel de puntos.
- **Función duplicada:** `_pips_por_recurso` repite `pips_por_recurso` de `tablero.py`.
- **Simplificaciones de la fase 3:** reparto parejo en `produccion_efectiva` y turnos calculados por separado, sin ladrón.
